"use client"

import { create } from "zustand"
import { persist } from "zustand/middleware"
import { api } from "../api/api"
import type { User } from "../types/user"

interface AuthState {
  user: User | null
  token: string | null
  isAuthenticated: boolean
  login: (email: string, password: string) => Promise<void>
  logout: () => void
  switchRole: () => void
  register: (name: string, email: string, password: string) => Promise<void>
  updateUser: (updatedUser: User) => void
}

// Create auth store with persistence
export const useAuthStore = create<AuthState>()(
  persist(
    (set) => ({
      user: null,
      token: null,
      isAuthenticated: false,

      // Login function
      login: async (email: string, password: string) => {
        try {
          // Call login API
          const response = await api.auth.login(email, password)

          set({
            user: response.user,
            token: response.token,
            isAuthenticated: true,
          })
        } catch (error) {
          console.error("Login failed:", error)
          throw error
        }
      },

      // Logout function
      logout: () => {
        set({
          user: null,
          token: null,
          isAuthenticated: false,
        })
      },

      // Switch between owner and guest roles (for demo purposes)
      switchRole: () => {
        set((state) => {
          if (!state.user) return state

          const newRole = state.user.role === "owner" ? "guest" : "owner"

          return {
            user: {
              ...state.user,
              role: newRole,
            },
          }
        })
      },

      // Register function
      register: async (name: string, email: string, password: string) => {
        try {
          // Call register API
          const response = await api.auth.register(name, email, password)

          set({
            user: response.user,
            token: response.token,
            isAuthenticated: true,
          })
        } catch (error) {
          console.error("Registration failed:", error)
          throw error
        }
      },

      // Update user function
      updateUser: (updatedUser: User) => {
        set({
          user: updatedUser,
        })
      },
    }),
    {
      name: "auth-storage",
    },
  ),
)
