import { create } from "zustand"
import { api } from "../api/api"
import type { Device } from "../types/device"

interface DeviceState {
  devices: Device[]
  loading: boolean
  error: string | null
  fetchDevices: () => Promise<void>
  getDeviceHistoricalData: (deviceId: string, timeRange: string) => any[]
}

export const useDeviceStore = create<DeviceState>((set, get) => ({
  devices: [],
  loading: false,
  error: null,

  // Fetch devices from API
  fetchDevices: async () => {
    try {
      set({ loading: true, error: null })

      // Call devices API
      const devices = await api.devices.getAll()

      set({
        devices,
        loading: false,
      })
    } catch (error) {
      console.error("Failed to fetch devices:", error)
      set({
        loading: false,
        error: "Failed to fetch devices",
      })
    }
  },

  // Get historical data for a device (mock data)
  getDeviceHistoricalData: (deviceId: string, timeRange: string) => {
    // Generate mock historical data based on time range
    const dataPoints = timeRange === "24h" ? 24 : timeRange === "7d" ? 7 : 30
    const device = get().devices.find((d) => d.id === deviceId)

    if (!device) return []

    return Array.from({ length: dataPoints }).map((_, i) => {
      const baseTemp = device.temperature
      const baseHumidity = device.humidity

      // Add some random variation
      const tempVariation = Math.random() * 4 - 2
      const humidityVariation = Math.random() * 10 - 5

      let timeLabel = ""
      if (timeRange === "24h") {
        timeLabel = `${i}:00`
      } else if (timeRange === "7d") {
        const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
        timeLabel = days[i % 7]
      } else {
        timeLabel = `Day ${i + 1}`
      }

      return {
        time: timeLabel,
        temperature: +(baseTemp + tempVariation).toFixed(1),
        humidity: Math.max(0, Math.min(100, Math.round(baseHumidity + humidityVariation))),
      }
    })
  },
}))
