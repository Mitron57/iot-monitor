"use client"

import type React from "react"

import { useState } from "react"
import {
  Thermometer,
  Droplets,
  Wifi,
  WifiOff,
  Battery,
  BatteryLow,
  BatteryWarning,
  MoreVertical,
  RefreshCw,
  Power,
  PowerOff,
} from "lucide-react"
import type { Device } from "../../types/device"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "../ui/card"
import { Badge } from "../ui/badge"
import { Button } from "../ui/button"
import { useToast } from "../../hooks/use-toast"

interface DeviceCardProps {
  device: Device
  isSelected: boolean
  onSelect: () => void
  isOwner: boolean
}

export function DeviceCard({ device, isSelected, onSelect, isOwner }: DeviceCardProps) {
  const { toast } = useToast()
  const [isRefreshing, setIsRefreshing] = useState(false)

  // Handle device refresh
  const handleRefresh = (e: React.MouseEvent) => {
    e.stopPropagation()
    setIsRefreshing(true)

    // Simulate refresh
    setTimeout(() => {
      setIsRefreshing(false)
      toast({
        title: "Device refreshed",
        description: `${device.name} data has been updated`,
      })
    }, 1500)
  }

  // Handle device power toggle
  const handlePowerToggle = (e: React.MouseEvent) => {
    e.stopPropagation()
    if (!isOwner) {
      toast({
        title: "Permission denied",
        description: "Only owners can control devices",
        variant: "destructive",
      })
      return
    }

    toast({
      title: `Device ${device.status === "online" ? "powered off" : "powered on"}`,
      description: `${device.name} is now ${device.status === "online" ? "offline" : "online"}`,
    })
  }

  // Get status badge variant
  const getStatusVariant = () => {
    switch (device.status) {
      case "online":
        return "default"
      case "offline":
        return "destructive"
      case "warning":
        return "secondary"
      default:
        return "outline"
    }
  }

  // Get battery icon based on level
  const getBatteryIcon = () => {
    if (device.batteryLevel < 20) {
      return <BatteryWarning className="h-4 w-4 text-destructive" />
    } else if (device.batteryLevel < 50) {
      return <BatteryLow className="h-4 w-4 text-secondary" />
    } else {
      return <Battery className="h-4 w-4 text-primary" />
    }
  }

  return (
    <Card
      className={`device-card cursor-pointer transition-all hover:shadow-md ${isSelected ? "ring-2 ring-primary" : ""}`}
      onClick={onSelect}
    >
      <CardHeader className="pb-2">
        <div className="flex justify-between items-start">
          <CardTitle className="text-lg">{device.name}</CardTitle>
          <div className="relative">
            <Button variant="ghost" size="icon" onClick={(e) => e.stopPropagation()}>
              <MoreVertical className="h-4 w-4" />
            </Button>
            <div className="absolute right-0 mt-2 w-48 bg-background rounded-md shadow-lg border hidden group-hover:block">
              <div className="py-1">
                <button className="w-full text-left px-4 py-2 text-sm hover:bg-accent" onClick={handleRefresh}>
                  <RefreshCw className="inline-block mr-2 h-4 w-4" />
                  <span>Refresh</span>
                </button>
                {isOwner && (
                  <button className="w-full text-left px-4 py-2 text-sm hover:bg-accent" onClick={handlePowerToggle}>
                    {device.status === "online" ? (
                      <>
                        <PowerOff className="inline-block mr-2 h-4 w-4" />
                        <span>Turn Off</span>
                      </>
                    ) : (
                      <>
                        <Power className="inline-block mr-2 h-4 w-4" />
                        <span>Turn On</span>
                      </>
                    )}
                  </button>
                )}
              </div>
            </div>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <Badge variant={getStatusVariant()}>
            {device.status === "online" ? <Wifi className="mr-1 h-3 w-3" /> : <WifiOff className="mr-1 h-3 w-3" />}
            {device.status}
          </Badge>
          <Badge variant="outline" className="text-xs">
            {device.type}
          </Badge>
        </div>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 gap-2">
          <div className="flex items-center gap-2 bg-muted/50 p-2 rounded-md">
            <Thermometer className="h-4 w-4 text-orange-500" />
            <span className="text-sm">{device.temperature}°C</span>
          </div>
          <div className="flex items-center gap-2 bg-muted/50 p-2 rounded-md">
            <Droplets className="h-4 w-4 text-blue-500" />
            <span className="text-sm">{device.humidity}%</span>
          </div>
        </div>
      </CardContent>
      <CardFooter className="pt-0 flex justify-between">
        <div className="flex items-center text-xs text-muted-foreground">
          <span>Last updated: {device.lastUpdated}</span>
        </div>
        <div className="flex items-center gap-1">
          {getBatteryIcon()}
          <span className="text-xs">{device.batteryLevel}%</span>
        </div>
      </CardFooter>
    </Card>
  )
}
