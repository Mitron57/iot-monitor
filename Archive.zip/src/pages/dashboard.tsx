"use client"

import { useEffect, useState } from "react"
import { useNavigate } from "react-router-dom"
import { animate, stagger } from "animejs"
import { useAuthStore } from "../stores/auth-store"
import { useDeviceStore } from "../stores/device-store"
import { Header } from "../components/header"
import { DeviceCard } from "../components/device/device-card"
import { DeviceCardSkeleton } from "../components/device/device-card-skeleton"
import { DeviceChart } from "../components/device/device-chart"
import { NotificationPopup } from "../components/notification/notification-popup"
import { useToast } from "../hooks/use-toast"

export default function DashboardPage() {
  const { isAuthenticated, user } = useAuthStore()
  const { devices, fetchDevices, loading } = useDeviceStore()
  const navigate = useNavigate()
  const { toast } = useToast()
  const [showNotification, setShowNotification] = useState(false)
  const [selectedDevice, setSelectedDevice] = useState<string | null>(null)

  // Redirect if not authenticated
  useEffect(() => {
    if (!isAuthenticated) {
      navigate("/login")
    }
  }, [isAuthenticated, navigate])

  // Fetch devices on mount
  useEffect(() => {
    if (isAuthenticated) {
      fetchDevices()

      // Show welcome notification
      setTimeout(() => {
        toast({
          title: `Welcome ${user?.role === "owner" ? "Owner" : "Guest"}!`,
          description: "You can monitor your IoT devices here",
        })
      }, 1000)

      // Show a demo notification after 3 seconds
      setTimeout(() => {
        setShowNotification(true)
        setTimeout(() => setShowNotification(false), 5000)
      }, 3000)
    }
  }, [isAuthenticated, fetchDevices, toast, user?.role])

  // Animate device cards when they load
  useEffect(() => {
    if (!loading && devices.length > 0) {
      animate(".device-card", {
        opacity: [0, 1],
        translateY: [20, 0],
        delay: stagger(150),
        ease: "outExpo",
      })
    }
  }, [loading, devices])

  // Handle device selection for chart view
  const handleDeviceSelect = (deviceId: string) => {
    setSelectedDevice(deviceId === selectedDevice ? null : deviceId)
  }

  if (!isAuthenticated) {
    return null
  }

  return (
    <div className="min-h-screen bg-background">
      <Header />

      <main className="container mx-auto p-4 pt-24">
        <h1 className="text-3xl font-bold mb-6">Device Dashboard</h1>

        {/* Device Cards Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4 mb-8">
          {loading
            ? // Show skeletons while loading
              Array.from({ length: 4 }).map((_, index) => <DeviceCardSkeleton key={index} />)
            : // Show device cards
              devices.map((device) => (
                <DeviceCard
                  key={device.id}
                  device={device}
                  isSelected={device.id === selectedDevice}
                  onSelect={() => handleDeviceSelect(device.id)}
                  isOwner={user?.role === "owner"}
                />
              ))}
        </div>

        {/* Charts Section */}
        {selectedDevice && (
          <div className="bg-card rounded-lg p-4 shadow-md mb-8">
            <h2 className="text-xl font-semibold mb-4">
              Device Statistics: {devices.find((d) => d.id === selectedDevice)?.name}
            </h2>
            <DeviceChart deviceId={selectedDevice} />
          </div>
        )}

        {/* Coming Soon Sections */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
          <div className="bg-card rounded-lg p-6 shadow-md border border-dashed border-muted-foreground/50">
            <h2 className="text-xl font-semibold mb-2">Device Management</h2>
            <p className="text-muted-foreground">Coming soon! Add, edit, and remove your IoT devices.</p>
          </div>
          <div className="bg-card rounded-lg p-6 shadow-md border border-dashed border-muted-foreground/50">
            <h2 className="text-xl font-semibold mb-2">Automation Rules</h2>
            <p className="text-muted-foreground">Coming soon! Create rules to automate your IoT devices.</p>
          </div>
        </div>
      </main>

      {/* Notification Popup */}
      {showNotification && (
        <NotificationPopup
          title="Temperature Alert"
          message="Device 'Living Room Sensor' reported high temperature!"
          type="warning"
          onClose={() => setShowNotification(false)}
        />
      )}
    </div>
  )
}
